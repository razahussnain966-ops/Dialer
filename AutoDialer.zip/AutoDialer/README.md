# Auto Dialer (Android)

Calls a list of numbers one by one using your phone's SIM.

## Build
1. Install Android Studio (Koala or newer).
2. File > Open > select this `AutoDialer` folder. Let Gradle sync finish.
3. Connect your Android phone (USB debugging on) and press Run, or use Build > Build APK(s) and install the APK.

## Use
1. Open the app and paste numbers (one per line or comma separated), or import a .txt/.csv file.
2. Set "Max seconds per call" (includes ringing; the app hangs up after this) and "Gap between calls".
3. Tap Start and allow the three phone permissions.
4. Keep the app open on screen (screen stays awake). Tap Stop any time.

## Notes
- Android only (iPhone does not allow apps to place calls automatically).
- Dual SIM: the call uses your phone's default calling SIM. Change it in Settings > SIM / Calls.
- Use only for people who expect your calls, and follow local telecom rules.
